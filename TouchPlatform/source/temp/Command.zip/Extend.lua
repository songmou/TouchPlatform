toast('测试');
finishTag=false;