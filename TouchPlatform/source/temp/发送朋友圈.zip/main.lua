require("TSLib");	--触动精灵函数扩展库
require("basic");

require("timeline");

pressHomeKey(0);    --Home 键
pressHomeKey(1);

toast("获取数据中...");
mSleep(2*radix);


local DeviceId = getDeviceID(); 
local loadDevice=loadconfig();


toast("开始执行脚本："..loadDevice.Name);
mSleep(2*radix);

RebootApp("com.tencent.xin");

mSleep(2*radix);
click(84,1080,30);
mSleep(3*radix);

if not multiColor({{587,71,0xffffff},{588,96,0xffffff},{575,85,0xffffff}},fuzzy) then
	toast("主界面异常");
	mSleep(5*radix);
	return ;
end

if loadDevice.imageArray==nil then
	toast("纯文本消息");
	mSleep(5*radix);
end


local shareResult=sharingTxtAction(loadDevice.SendMsg);

--[[local shareResult=sharingImageAction(
	{"404.jpg","header.jpg"},
	"微信朋友圈文本测试内容");
if(shareResult) then
	toast("朋友圈发送成功");
end
mSleep(1*1000*radix);
]]
	

ToastAwait(loadDevice.RestTime,"距离脚本结束");

toast("脚本'"..loadDevice.Name.."'已结束运行");
mSleep(2*radix);