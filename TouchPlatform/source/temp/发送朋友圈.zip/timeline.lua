require("TSLib");	--触动精灵函数扩展库
require("basic");

--从微信首页进入 朋友圈
function intoShareline()
	if not multiColor({{33,79, 0x39383e},{106,109, 0x434246},{497,85, 0x3b3a3f}},fuzzy) then
		toast("不是在微信主页");
		return false;
	end
	
	--点   发现
	touchDown(1, 399, 1075);
	mSleep(3*radix); 
	touchUp(1, 399, 1073);
	mSleep(1*radix); 
	
	--通过朋友圈的图标判断是不是在发现的界面
	if not multiColor({{38,199,0xffc817},{53,217,0x66d020},{56,184,0xfa5452},{71,203,0x5283f0}},fuzzy) then
		toast("朋友圈界面异常");
		return false;
	end
	
	--点朋友圈
	touchDown(1, 261, 205);
	mSleep(20); 
	touchUp(1, 260, 205);
	mSleep(1*radix); 
	
	if not multiColor({{573,87,0xffffff},{608,86,0xffffff},{590,69,0xffffff},{590,99,0xffffff}},fuzzy) then
		toast("未能成功进入朋友圈");
		return false;
	end
end


--发送朋友圈纯文本内容
function sharingTxtAction(content)
	mSleep(0.5*radix);
	if string.len(content)  == 0 then 
		return false;
	end
	
	intoShareline();
	
	--点朋友圈相机
	touchDown(1, 573, 87);
	mSleep(3*radix); 
	touchUp(1, 573, 85);
	mSleep(1*radix); 
	
	if multiColor({{47,333,0xf9f7fa},{592,339,0xf9f7fa},{309,708,0xaeacaf}},fuzzy) then
		--出现提示
		touchDown(1, 321, 752);
		mSleep(20*radix); 
		touchUp(1, 320, 752);
		mSleep(1*radix); 
	end
	
	--输入发送的内容
	inputText(content);
	mSleep(1*radix); 
	
	
	touchDown(1, 346,353); --在 (150, 550) 按下
	mSleep(200);
	touchMove(1, 331,140); --移动到 (150, 600)
	mSleep(200);
	touchUp(1, 320, 140);
	mSleep(2*radix);
	--需要勾选发送到QQ空间
	if multiColor({{35,743,0xc9c9c9},{65,743,0xc9c9c9},{72,743,0xefeff4}},fuzzy) then
		--如果出现qq空间的图标
		--toast("检查到图标");
		click(51,748,40);
		mSleep(1*radix);

	end
	
	
	--发送
	touchDown(1, 587, 83);
	mSleep(20); 
	touchUp(1, 587, 80);
	mSleep(1*radix); 
	
	return true;
end


